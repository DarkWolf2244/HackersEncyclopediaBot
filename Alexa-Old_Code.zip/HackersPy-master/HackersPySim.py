#Import Modules
import json
try:
#Define Programs
#Define Nodes
#Operations Area
#Error Catchment
except FileNotFoundError:
    print ("Error, could not find 1 or more files required, please ensure all files are downloaded and in dir with the Py file")
