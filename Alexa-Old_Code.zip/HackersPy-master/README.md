This Bot was meant to list Hackers The Game, Program and Node statistics, as well as calculate time for X program(s) to take Y Node(s).
Made by CodeWritten and Molchu, with assistance from Amethysm
